package com.wangzaiplus.test.service.strategy;

public interface CalculateService {

    int calculate(int a, int b);

}

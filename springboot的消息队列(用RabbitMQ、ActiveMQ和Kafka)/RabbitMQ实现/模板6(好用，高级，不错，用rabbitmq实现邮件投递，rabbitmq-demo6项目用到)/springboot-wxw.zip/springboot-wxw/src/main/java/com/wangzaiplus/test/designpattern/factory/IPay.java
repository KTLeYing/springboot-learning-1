package com.wangzaiplus.test.designpattern.factory;

public interface IPay {

    boolean pay();

}

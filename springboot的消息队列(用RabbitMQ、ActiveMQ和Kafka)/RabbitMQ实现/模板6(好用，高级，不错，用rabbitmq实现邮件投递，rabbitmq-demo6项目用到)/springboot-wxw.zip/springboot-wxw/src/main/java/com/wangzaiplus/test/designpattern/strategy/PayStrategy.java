package com.wangzaiplus.test.designpattern.strategy;

public interface PayStrategy {

    void pay(String userId);

}

package com.wangzaiplus.test.pojo;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class CalculateDto {

    Integer type;
    Integer a;
    Integer b;

}
